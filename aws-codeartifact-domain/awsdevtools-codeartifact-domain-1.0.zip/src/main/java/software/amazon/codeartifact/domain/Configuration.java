package software.amazon.codeartifact.domain;

class Configuration extends BaseConfiguration {

    public Configuration() {
        super("awsdevtools-codeartifact-domain.json");
    }
}
